public interface Eq<T> {
	public boolean eq(T that);
}