public abstract class Exp {
	public abstract Exp simp();
}