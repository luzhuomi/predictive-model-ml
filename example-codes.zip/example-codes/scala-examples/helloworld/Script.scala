println("Hello World!")

/*
$ scala HelloWorldScript.scala
*/