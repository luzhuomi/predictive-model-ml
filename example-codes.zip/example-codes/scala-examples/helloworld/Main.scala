object Main extends App 
{
	println("Hello world!")
}

/*
$ scalac Main.scala
$ scala Main
Hello world!
*/ 